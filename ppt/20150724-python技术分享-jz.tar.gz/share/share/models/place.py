from bson import ObjectId
from . import Model

class Place(Model):
    __database__ = "fe_share"
    __collection__ = "place"

    @classmethod
    def create(cls):
        return cls({
            "_id": ObjectId(),
            "name": ""
        })
