from .. import app
from mongoassist import Model as _Model

class Model(_Model):
    __dburi__ = app.config["DBURI"]
    __database__ = "fe_share"
    __appname__ = "share"
