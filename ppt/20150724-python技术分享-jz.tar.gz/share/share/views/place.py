from ..shortcuts import *
from ..models.place import Place

@app.route("/")
def main():
    return render_template("place/index.html")

@app.route("/place/set_place", methods=["POST"])
def setPlace():
    name = request.form.get("name", "default name")
    place = Place.create()
    place["name"] = name
    place.save()
    id = place["_id"]
    return success("success", url="/place/show_place/"+str(id))

@app.route("/place/show_place/<string(length=24):id>")
def showPlace(id):
    print id
    place = Place.findOne({"_id": ObjectId(id)}) or {}
    print place
    name = place["name"]
    return render_template("place/show.html", name=name)

@app.route("/hello")
def hello():
    return success("success", name="name", belive={"isTrue": True})
