from flask import Flask
app = Flask(__name__)
app.config.from_object('share.settings')
app.debug = True

from os.path import abspath, join
import sys
sys.path.insert(0, abspath(join(app.root_path, '..', 'lib')))

import views
import views.place
