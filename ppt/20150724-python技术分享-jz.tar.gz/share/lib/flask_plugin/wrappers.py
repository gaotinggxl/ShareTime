# -*- coding: utf-8 -*-
import re
from werkzeug.wrappers import Request, Response as WerkzeugResponse
from werkzeug.exceptions import NotFound, MethodNotAllowed, BadRequest
from werkzeug.contrib.securecookie import SecureCookie
try:
    from simplejson import dumps
except ImportError:
    from json import dumps
try:
    from bson.json_util import default, object_hook
except ImportError:
    default = object_hook = None


class Response(WerkzeugResponse):
    default_mimetype = 'text/html'


def JsonResponse(obj):
    return Response(dumps(obj, default=default), content_type="application/json")


def error(message, **kw):
    result = {"result": False, "message": message}
    result.update(kw)
    return Response(dumps(result, default=default), content_type="application/json")


def success(message, **kw):
    result = {"result": True, "message": message}
    result.update(kw)
    return Response(dumps(result, default=default), content_type="application/json")

