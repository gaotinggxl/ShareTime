#-*- coding: utf-8 -*-
from share import app
from flask.ext.script import Manager
from flask.ext.script.commands import Clean, ShowUrls
manager = Manager(app)
manager.add_command('clean', Clean())
manager.add_command('urls', ShowUrls())

if __name__ == "__main__":
    manager.run()
